# LastMile Delivery Tracker

A full-stack last-mile delivery management platform with role-based access (Customer / Agent / Admin), a config-driven rate calculation engine, auto-assignment logic, and real-time order tracking with email notifications.

**Stack:** Node.js · Express · Prisma · PostgreSQL · React · Vite

---

## Demo Credentials

| Role     | Email                    | Password      |
|----------|--------------------------|---------------|
| Admin    | admin@lastmile.com       | Password123!  |
| Agent 1  | agent1@lastmile.com      | Password123!  |
| Agent 2  | agent2@lastmile.com      | Password123!  |
| Customer | customer@lastmile.com    | Password123!  |

**Sample pincodes (from seed):**
- `110001` → North Delhi
- `110017` → South Delhi
- `122001` → Gurugram
- `201301` → Noida

---

## Hosted URLs

- **Frontend:** `https://lastmile-frontend.vercel.app`
- **Backend API:** `https://lastmile-backend.up.railway.app`

---

## Local Setup

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (local or cloud)

### 1. Clone & Install

```bash
git clone https://github.com/your-username/lastmile-delivery-tracker
cd lastmile-delivery-tracker
```

### 2. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your DATABASE_URL, JWT_SECRET, and email credentials
```

**.env:**
```env
DATABASE_URL="postgresql://user:password@localhost:5432/lastmile"
JWT_SECRET="your-secret-here"
PORT=5000
FRONTEND_URL="http://localhost:5173"
EMAIL_USER="youremail@gmail.com"
EMAIL_PASS="your-gmail-app-password"
```

> **Gmail App Password:** Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords), generate a 16-character app password. Email is optional — the system skips sending if credentials are absent and logs to console instead.

```bash
# Push schema to DB and generate Prisma client
npx prisma db push
npx prisma generate

# Seed demo data (zones, pincodes, rate cards, users, agents)
node prisma/seed.js

# Start dev server
npm run dev
```

Backend runs at `http://localhost:5000`

### 3. Frontend Setup

```bash
cd frontend
npm install
cp .env.example .env
# .env: VITE_API_URL=http://localhost:5000/api

npm run dev
```

Frontend runs at `http://localhost:5173`

---

## DB Schema

```
User          — id, name, email, password, phone, role (CUSTOMER|AGENT|ADMIN)
Zone          — id, name
Area          — id, pincode (unique), city, state, zoneId → Zone
RateCard      — id, zoneId, orderType (B2B|B2C), isIntraZone, baseRate, codSurcharge
               unique(zoneId, orderType, isIntraZone)
Agent         — id, userId → User, zoneId → Zone, isAvailable, latitude, longitude
Order         — id, customerId, createdById, pickupAddress, pickupPincode, dropAddress,
               dropPincode, length, breadth, height, actualWeight, volumetricWeight,
               chargeableWeight, orderType, paymentType, pickupZoneId, dropZoneId,
               isIntraZone, baseCharge, codSurcharge, totalCharge, agentId, status,
               rescheduledDate, failureReason, createdAt, updatedAt
TrackingLog   — id, orderId, status, note, actorId, actorRole, createdAt (immutable)
```

---

## Rate Calculation Logic

The engine (`src/services/rateEngine.service.js`) runs on every order creation and preview request. All rates are DB-driven — no hardcoding.

### Step-by-step

```
1. Zone Detection
   pickupZone = Area.findUnique({ pincode: pickupPincode }).zone
   dropZone   = Area.findUnique({ pincode: dropPincode }).zone
   → Fails loudly if pincode not mapped to any zone

2. Intra / Inter Zone
   isIntraZone = (pickupZone.id === dropZone.id)

3. Volumetric Weight
   volumetricWeight = (length × breadth × height) / 5000  [cm → kg]

4. Chargeable Weight
   chargeableWeight = max(actualWeight, volumetricWeight)

5. Rate Card Lookup
   RateCard.findUnique({ zoneId: pickupZone.id, orderType, isIntraZone })
   → Contains baseRate (₹/kg) and codSurcharge (₹ flat)

6. Final Charge
   baseCharge   = chargeableWeight × baseRate
   codSurcharge = paymentType === 'COD' ? rateCard.codSurcharge : 0
   totalCharge  = baseCharge + codSurcharge
```

### Preview Endpoint
`POST /api/orders/preview-charge` returns the full breakdown before confirmation. The confirmed order stores all computed values as a snapshot — future rate card changes never affect past orders.

---

## API Reference

All routes require `Authorization: Bearer <token>` except `/auth/register` and `/auth/login`.

### Auth

| Method | Endpoint              | Access | Description          |
|--------|-----------------------|--------|----------------------|
| POST   | /auth/register        | Public | Register as customer |
| POST   | /auth/login           | Public | Login (any role)     |
| GET    | /auth/me              | All    | Get current user     |

### Zones

| Method | Endpoint                    | Access | Description             |
|--------|-----------------------------|--------|-------------------------|
| GET    | /zones                      | All    | List all zones + areas  |
| POST   | /zones                      | Admin  | Create zone             |
| POST   | /zones/:zoneId/areas        | Admin  | Add pincode to zone     |
| DELETE | /zones/areas/:areaId        | Admin  | Remove pincode          |

### Rate Cards

| Method | Endpoint                    | Access | Description             |
|--------|-----------------------------|--------|-------------------------|
| GET    | /rate-cards                 | All    | List all rate cards     |
| POST   | /rate-cards                 | Admin  | Create/update rate card |
| DELETE | /rate-cards/:id             | Admin  | Delete rate card        |

### Orders

| Method | Endpoint                        | Access         | Description                       |
|--------|---------------------------------|----------------|-----------------------------------|
| POST   | /orders/preview-charge          | All (auth)     | Preview charge before order       |
| POST   | /orders                         | Customer/Admin | Create order                      |
| GET    | /orders                         | All (auth)     | List orders (role-filtered)       |
| GET    | /orders/:id                     | All (auth)     | Get single order + tracking log   |
| POST   | /orders/:id/assign              | Admin          | Manually assign agent             |
| POST   | /orders/:id/auto-assign         | Admin          | Auto-assign nearest agent         |
| PATCH  | /orders/:id/status              | Agent/Admin    | Update order status               |
| POST   | /orders/:id/reschedule          | Customer       | Reschedule failed delivery        |

### Agents

| Method | Endpoint                    | Access | Description              |
|--------|-----------------------------|--------|--------------------------|
| POST   | /agents                     | Admin  | Create agent             |
| GET    | /agents                     | Admin  | List all agents          |
| PATCH  | /agents/location            | Agent  | Update own GPS location  |
| PATCH  | /agents/availability        | Agent  | Toggle availability      |
| PATCH  | /agents/:id/zone            | Admin  | Reassign agent to zone   |

### Admin

| Method | Endpoint                        | Access | Description              |
|--------|---------------------------------|--------|--------------------------|
| GET    | /admin/stats                    | Admin  | Dashboard statistics     |
| GET    | /admin/customers                | Admin  | List all customers       |
| PATCH  | /admin/orders/:id/override      | Admin  | Force any status change  |

---

## Order Status Lifecycle

```
PENDING → CONFIRMED → ASSIGNED → PICKED_UP → IN_TRANSIT → OUT_FOR_DELIVERY → DELIVERED
                                                                           ↘
                                                                           FAILED → RESCHEDULED → ASSIGNED → ...
```

Valid transitions are enforced server-side via a `VALID_TRANSITIONS` map. Admins can bypass via the override endpoint. Every status change creates an immutable `TrackingLog` entry with timestamp, actor ID, and role.

---

## Auto-Assignment Logic

1. **Zone-first:** Find available agents (`isAvailable = true`) in the pickup zone.
2. **Proximity:** If agents have GPS coordinates, rank by Haversine distance from pickup.
3. **Fallback:** If no agents in pickup zone, expand search to all available agents (ordered by fewest active orders).
4. On assignment, agent's `isAvailable` is set to `false`.
5. On `DELIVERED` or `FAILED`, agent is automatically freed.

---

## Failed Delivery Flow

1. Agent sets status to `FAILED` with a `failureReason`.
2. Agent is freed (`isAvailable = true`).
3. Customer receives email notification.
4. Customer calls `POST /orders/:id/reschedule` with a new date.
5. System sets status to `RESCHEDULED`, auto-assigns a fresh agent.
6. Customer receives `RESCHEDULED` notification.

---

## Email Notifications

Uses Nodemailer with Gmail (free tier). Notifications sent on every status change: `CONFIRMED`, `ASSIGNED`, `PICKED_UP`, `IN_TRANSIT`, `OUT_FOR_DELIVERY`, `DELIVERED`, `FAILED`, `RESCHEDULED`.

If `EMAIL_USER`/`EMAIL_PASS` are not set, notifications are skipped gracefully and logged to console — the main order flow is unaffected.

---

## Deployment

### Backend (Railway)
1. Create a new Railway project, add a PostgreSQL plugin.
2. Deploy the `backend/` directory.
3. Set environment variables from `.env.example`.
4. Run `npx prisma db push && node prisma/seed.js` via Railway's shell.

### Frontend (Vercel)
1. Import the `frontend/` directory into Vercel.
2. Set `VITE_API_URL=https://your-railway-backend-url/api`.
3. Deploy.

---

## Project Structure

```
lastmile/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma       # DB schema
│   │   └── seed.js             # Demo data seeder
│   └── src/
│       ├── controllers/        # auth, zone, rateCard, order
│       ├── middleware/         # JWT auth + role authorization
│       ├── routes/             # Express routers
│       ├── services/
│       │   ├── rateEngine.service.js   # Rate calculation engine
│       │   ├── assignment.service.js   # Auto-assign logic
│       │   └── email.service.js        # Nodemailer notifications
│       └── utils/
│           └── prisma.js       # Prisma client singleton
└── frontend/
    └── src/
        ├── components/         # Topbar, StatusPill
        ├── context/            # AuthContext
        ├── pages/              # All role-based pages
        └── services/           # Axios API client
```
